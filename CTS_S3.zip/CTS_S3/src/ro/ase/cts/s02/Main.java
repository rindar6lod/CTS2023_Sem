package ro.ase.cts.s02;

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        /*//Calculator calculator = new Calculator();
        CalculatorRefactored calculatorRefactored = new CalculatorRefactored();
        double result = calculatorRefactored.calculatePowXPlusPowY();
        System.out.println("Rezultatul este: " + result);*/


        MatrixDataHandler mH = new MatrixDataHandler(5, 7, "matrix.txt");
        mH.modifyValueAndUpdateFile(3, 4, 345);
    }
}
