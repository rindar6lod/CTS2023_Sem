package ro.ase.cts.s02;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Calculator {
    /**
     * Aceasta metoda calculeaza suma dintre x ridicat la puterea a-5a si y ridicat la putearea a-7a.
     * @return Returneaza rezultatul calculat.
     * @throws IOException Arunca exceptie daca datele introduse nu au formatul corect.
     */

    public double raiseToPower(double pow) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Tastati valoarea:");
        double x = Double.parseDouble(reader.readLine());

        double rez = x;
        for (int i = 1; i < pow; i++) {
            rez *= x;
        }

        return rez;
    }

    public double addPowers5and7() throws IOException {
        double result = 0.0;

        double x5 = raiseToPower(5);
        double y7 = raiseToPower(7);

        result = x5 + y7;
        return result;
    }
}